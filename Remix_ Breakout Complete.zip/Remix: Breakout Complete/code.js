var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["536d788c-eb62-49c5-b080-ad9924d144d5","9e88ae06-6927-4b9e-a7f9-41a879221fd8","838d5c87-fc8e-4557-9a1e-29eb07f65eef","958c3f12-323b-4b73-8201-1753d4c7c7d3","42cf5539-be7e-48cd-8452-f80ae0144806","ac4a7635-8953-43bb-ab79-80b14e5f1450","1f5fe5e4-320a-4dcb-bd88-3f65f238d439"],"propsByKey":{"536d788c-eb62-49c5-b080-ad9924d144d5":{"name":"powerupGreen_1","sourceUrl":"assets/api/v1/animation-library/gamelab/guMKL4NW5b2v3Cb_F4s84HNuKxURs3S2/category_video_games/powerupGreen.png","frameSize":{"x":34,"y":33},"frameCount":1,"looping":true,"frameDelay":2,"version":"guMKL4NW5b2v3Cb_F4s84HNuKxURs3S2","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":34,"y":33},"rootRelativePath":"assets/api/v1/animation-library/gamelab/guMKL4NW5b2v3Cb_F4s84HNuKxURs3S2/category_video_games/powerupGreen.png"},"9e88ae06-6927-4b9e-a7f9-41a879221fd8":{"name":"powerupBlue_1","sourceUrl":"assets/api/v1/animation-library/gamelab/8fzZrdBd565h4o5wjlCW1_2gX5RI7ZUL/category_video_games/powerupBlue.png","frameSize":{"x":34,"y":33},"frameCount":1,"looping":true,"frameDelay":2,"version":"8fzZrdBd565h4o5wjlCW1_2gX5RI7ZUL","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":34,"y":33},"rootRelativePath":"assets/api/v1/animation-library/gamelab/8fzZrdBd565h4o5wjlCW1_2gX5RI7ZUL/category_video_games/powerupBlue.png"},"838d5c87-fc8e-4557-9a1e-29eb07f65eef":{"name":"powerupRed_1","sourceUrl":"assets/api/v1/animation-library/gamelab/PxdctBAoH0Dk5waypvVop.CJ8s20QPrs/category_video_games/powerupRed.png","frameSize":{"x":34,"y":33},"frameCount":1,"looping":true,"frameDelay":2,"version":"PxdctBAoH0Dk5waypvVop.CJ8s20QPrs","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":34,"y":33},"rootRelativePath":"assets/api/v1/animation-library/gamelab/PxdctBAoH0Dk5waypvVop.CJ8s20QPrs/category_video_games/powerupRed.png"},"958c3f12-323b-4b73-8201-1753d4c7c7d3":{"name":"powerupYellow_1","sourceUrl":"assets/api/v1/animation-library/gamelab/uAxvFw3MJ9tNtaLaWzAOrRFOqI8J8Ttt/category_video_games/powerupYellow.png","frameSize":{"x":34,"y":33},"frameCount":1,"looping":true,"frameDelay":2,"version":"uAxvFw3MJ9tNtaLaWzAOrRFOqI8J8Ttt","categories":["video_games"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":34,"y":33},"rootRelativePath":"assets/api/v1/animation-library/gamelab/uAxvFw3MJ9tNtaLaWzAOrRFOqI8J8Ttt/category_video_games/powerupYellow.png"},"42cf5539-be7e-48cd-8452-f80ae0144806":{"name":"bocceball_1","sourceUrl":"assets/api/v1/animation-library/gamelab/PsL7aQMAiQPU3mxOT28VFMthN6yvstH0/category_sports/bocceball.png","frameSize":{"x":393,"y":394},"frameCount":1,"looping":true,"frameDelay":2,"version":"PsL7aQMAiQPU3mxOT28VFMthN6yvstH0","categories":["sports"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":393,"y":394},"rootRelativePath":"assets/api/v1/animation-library/gamelab/PsL7aQMAiQPU3mxOT28VFMthN6yvstH0/category_sports/bocceball.png"},"ac4a7635-8953-43bb-ab79-80b14e5f1450":{"name":"curtain_top_1","sourceUrl":"assets/api/v1/animation-library/gamelab/fKiSp6DMxy8IA9TFoRhPaeuf_GWeaWQa/category_household_objects/curtain_top.png","frameSize":{"x":200,"y":63},"frameCount":1,"looping":true,"frameDelay":2,"version":"fKiSp6DMxy8IA9TFoRhPaeuf_GWeaWQa","categories":["household_objects"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":200,"y":63},"rootRelativePath":"assets/api/v1/animation-library/gamelab/fKiSp6DMxy8IA9TFoRhPaeuf_GWeaWQa/category_household_objects/curtain_top.png"},"1f5fe5e4-320a-4dcb-bd88-3f65f238d439":{"name":"360_F_357888819_XvattGqyaKLQtZ9JfW1QVTRVTaLkItug.jpg_1","sourceUrl":"assets/v3/animations/4uNPa4M5Fr6i7WxO9i_AaLrH2iBC4YPrbxAM9ydB_JA/1f5fe5e4-320a-4dcb-bd88-3f65f238d439.png","frameSize":{"x":600,"y":360},"frameCount":1,"looping":true,"frameDelay":4,"version":"Hwd0nYx3j7qILuipkDdP_OSXASgQ5jgZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":600,"y":360},"rootRelativePath":"assets/v3/animations/4uNPa4M5Fr6i7WxO9i_AaLrH2iBC4YPrbxAM9ydB_JA/1f5fe5e4-320a-4dcb-bd88-3f65f238d439.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var huu = createSprite(200, 200, 1000, 1000);
huu.setAnimation("360_F_357888819_XvattGqyaKLQtZ9JfW1QVTRVTaLkItug.jpg_1");
// Keep the box in the air by moving the paddle with the left and right arrows.
var paddle = createSprite(200, 375, 50, 15);
paddle.setAnimation("curtain_top_1");
paddle.width = 100;
paddle.height = 20;
var ball = createSprite(150, 250, 20, 20);
ball.setAnimation("bocceball_1");
ball.height = 30;
ball.width = 30;

//Row 1
var box1 = createSprite(25, 75, 50, 50);
box1.shapeColor="red";
box1.setAnimation("powerupRed_1");
var box2 = createSprite(75, 75, 50);
box2.shapeColor="blue";
box2.setAnimation("powerupYellow_1");
var box3 = createSprite(125, 75, 50, 50);
box3.shapeColor="red";
box3.setAnimation("powerupRed_1");
var box4 = createSprite(175, 75, 50, 50);
box4.shapeColor="blue";
box4.setAnimation("powerupYellow_1");
var box5 = createSprite(225, 75, 50, 50);
box5.shapeColor="red";
box5.setAnimation("powerupRed_1");
var box6 = createSprite(275, 75, 50, 50);
box6.shapeColor="blue";
box6.setAnimation("powerupYellow_1");
var box7 = createSprite(325, 75, 50, 50);
box7.shapeColor="red";
box7.setAnimation("powerupRed_1");
var box8 = createSprite(375, 75, 50, 50);
box8.shapeColor="blue";
box8.setAnimation("powerupYellow_1");

// Row 2
var box9 = createSprite(25, 125, 50, 50);
box9.shapeColor="blue";
box9.setAnimation("powerupYellow_1");
var box10 = createSprite(75, 125, 50, 50);
box10.shapeColor="red";
box10.setAnimation("powerupRed_1");
var box11 = createSprite(125, 125, 50, 50);
box11.shapeColor="blue";
box11.setAnimation("powerupYellow_1");
var box12 = createSprite(175, 125, 50, 50);
box12.shapeColor="red";
box12.setAnimation("powerupRed_1");
var box13 = createSprite(225, 125, 50, 50);
box13.shapeColor="blue";
box13.setAnimation("powerupYellow_1");
var box14 = createSprite(275, 125, 50, 50);
box14.shapeColor="red";
box14.setAnimation("powerupRed_1");
var box15 = createSprite(325, 125, 50, 50);
box15.shapeColor="blue";
box15.setAnimation("powerupYellow_1");
var box16 = createSprite(375, 125, 50, 50);
box16.shapeColor="red";
box16.setAnimation("powerupRed_1");
var box17 = createSprite(25, 25, 50, 50);
box17.shapeColor="blue";
box17.setAnimation("powerupYellow_1");
var box18 = createSprite(75, 25, 50, 50);
box18.shapeColor="blue";
box18.setAnimation("powerupRed_1");
var box19 = createSprite(125, 25, 50, 50);
box19.shapeColor="blue";
box19.setAnimation("powerupYellow_1");
var box20 = createSprite(175, 25, 50, 50);
box20.shapeColor="blue";
box20.setAnimation("powerupRed_1");
var box21 = createSprite(225, 25, 50, 50);
box21.shapeColor="blue";
box21.setAnimation("powerupYellow_1");
var box22 = createSprite(275, 25, 50, 50);
box22.shapeColor="blue";
box22.setAnimation("powerupRed_1");
var box23 = createSprite(325, 25, 50, 50);
box23.shapeColor="blue";
box23.setAnimation("powerupYellow_1");
var box24 = createSprite(375, 25, 50, 50);
box24.shapeColor="blue";
box24.setAnimation("powerupRed_1");


function draw() {
  background("white");
  
  if(keyDown("enter")){
    ball.velocityX = 5;
    ball.velocityY = 6;
  }
  
  createEdgeSprites();
  ball.bounceOff(rightEdge);
  ball.bounceOff(leftEdge);
  ball.bounceOff(topEdge);


  paddle.x=World.mouseX;

  
  if(ball.isTouching(box1)){
    box1.destroy();
  }
  
  if(ball.isTouching(box2)){
    box2.destroy();
  }
  
  if(ball.isTouching(box3)){ 
    box3.destroy();
  }
  
  if(ball.isTouching(box4)){
    box4.destroy();
  }
  
   if(ball.isTouching(box5)){ 
     box5.destroy();
  }
  
   if(ball.isTouching(box6)) {
     box6.destroy();
  }
  
  if(ball.isTouching(box7)) { 
    box7.destroy();
  }
  
  if(ball.isTouching(box8)){
    box8.destroy();
  }
  // row 2 
  if(ball.isTouching(box9)){
    box9.destroy();
  }
  
  if(ball.isTouching(box10)){
    box10.destroy();
  }
  
  if(ball.isTouching(box11)){ 
    box11.destroy();
  }
  
  if(ball.isTouching(box12)){
    box12.destroy();
  }
  
   if(ball.isTouching(box13)){ 
     box13.destroy();
  }
  
   if(ball.isTouching(box14)) {
     box14.destroy();
  }
  
  if(ball.isTouching(box15)) { 
    box15.destroy();
  }
  
  if(ball.isTouching(box16)){
    box16.destroy();
  }
  if(ball.isTouching(box17)){
    box17.destroy();
  }
  if(ball.isTouching(box18)){
    box18.destroy();
  }
  if(ball.isTouching(box19)){
    box19.destroy();
  }
  if(ball.isTouching(box20)){
    box20.destroy();
  }
  if(ball.isTouching(box21)){
    box21.destroy();
  }
  if(ball.isTouching(box22)){
    box22.destroy();
  }
  if(ball.isTouching(box23)){
    box23.destroy();
  }
  if(ball.isTouching(box24)){
    box24.destroy();
  }
  
  
  
  ball.bounceOff(paddle);
  
  
  
  
  drawSprites();

}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
